package com.orderflow.orderflowbackend.models;

public enum Role {
    CLIENT,
    COURIER,
    ADMIN
}
